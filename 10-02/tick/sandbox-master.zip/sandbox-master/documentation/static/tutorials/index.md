## Getting started

+ [Understanding the Sandbox](/tutorials/understanding-sandbox)
+ [Getting started with Flux](/tutorials/flux-getting-started)
+ [Learning Flux](https://docs.influxdata.com/flux)

## Tutorials

+ [Enabling Auth in InfluxDB](/tutorials/enable-auth)
+ [Create Alert](/tutorials/create-alert)
+ [Using the Telegraf socket_listener Plugin](/tutorials/telegraf-socket-listener)
